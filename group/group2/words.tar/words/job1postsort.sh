#!/bin/bash

sort -m sort.data.txt.* > sort.data.txt
uniq -c sort.data.txt > countsOfWords
echo "Finished!"
